<?php $title = 'Blog Detail | Committed to investment orientation, profit growth, and extensive global business penetration.';?>
<?php
$siteName = 'Royal 10 Investment Limited'?>
<?php $sitePhone = '+123 9898 500'?>
<?php $siteAddress = '256 Avenue, Mark Street, NewYork City'?>
<?php $siteEmail = 'info@royal10investmentltd.com'?>
<?php $siteFacebook = 'https://www.facebook.com/'?>
<?php $siteTwitter = 'https://twitter.com/home'?>
<?php $siteInstagram = 'https://www.instagram.com/'?>
<?php $siteLinkedin = 'https://www.linkedin.com/'?>
<?php $siteYear = date('Y')?>
<?php echo $__env->make('lib', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="img/image-cover.png">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">All Blogs</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='./'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Blogs</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>
        <!-- breadcrumb-area-end -->
        <!-- blog-area -->
        <section class="blog__area">
            <div class="container">
                <div class="blog__inner-wrap">
                    <div class="row">

                        <div class="col-70">
                            <div class="blog-post-wrap">
                                <div class="row gutter-24">

                                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='blog-details/<?php echo e($new->id); ?>'><img src="<?php echo e(('uploads/' .$new->imgs)); ?>" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog'>News</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i><?php echo e(\Carbon\Carbon::parse($new->dob)->format('M d, Y')); ?></li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='blog-details/<?php echo e($new->id); ?>'><?php echo e($new->title); ?></a></h2>
                                                <div class="blog-avatar">
                                                    <?php if($getUsers->image == NULL): ?>
                                                    <div class="avatar-thumb">
                                                        <img src="<?php echo e(asset('images/download.png')); ?>" alt="default-avatar" />
                                                     </div>
                                                    <?php else: ?>

                                                    <div class="avatar-thumb">
                                                        <img src="<?php echo e(('uploads/' .$getUsers->image)); ?>" alt="">
                                                    </div>
                                                        
                                                    <?php endif; ?>
                                                    
                                                    <div class="avatar-content">
                                                        <p>By <a href='blog-details/<?php echo e($new->id); ?>'><?php echo e($getUsers->name); ?></a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $evens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $even): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-md-6">
                                        <div class="blog__post-two shine-animate-item">
                                            <div class="blog__post-thumb-two">
                                                <a class='shine-animate' href='blog-details2/<?php echo e($even->id); ?>'><img src="<?php echo e(('uploads/' .$even->imgs)); ?>" alt=""></a>
                                            </div>
                                            <div class="blog__post-content-two">
                                                <div class="blog-post-meta">
                                                    <ul class="list-wrap">
                                                        <li>
                                                            <a class='blog__post-tag-two' href='blog'>Even</a>
                                                        </li>
                                                        <li><i class="fas fa-calendar-alt"></i><?php echo e(\Carbon\Carbon::parse($even->dob)->format('M d, Y')); ?></li>
                                                    </ul>
                                                </div>
                                                <h2 class="title"><a href='blog-details2/<?php echo e($even->id); ?>'><?php echo e($even->title); ?></a></h2>
                                                <div class="blog-avatar">
                                                    <?php if($getUserseven->image == NULL): ?>
                                                    <div class="avatar-thumb">
                                                        <img src="<?php echo e(asset('images/download.png')); ?>" alt="default-avatar" />
                                                     </div>
                                                    <?php else: ?>

                                                    <div class="avatar-thumb">
                                                        <img src="<?php echo e(('uploads/' .$getUserseven->image)); ?>" alt="">
                                                    </div>
                                                        
                                                    <?php endif; ?>
                                                    <div class="avatar-content">
                                                        <p>By <a href='blog-details2/<?php echo e($even->id); ?>'><?php echo e($getUserseven->name); ?></a></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </div>
                                <div class="pagination-wrap mt-40">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination list-wrap">
                                            
                                            <?php if($news->previousPageUrl()): ?>
                                                <li class="page-item">
                                                    <a class="page-link" href="<?php echo e($news->previousPageUrl()); ?>"><i class="fas fa-angle-double-left"></i></a>
                                                </li>
                                            <?php else: ?>
                                                <li class="page-item disabled">
                                                    <a class="page-link" href="#"><i class="fas fa-angle-double-left"></i></a>
                                                </li>
                                            <?php endif; ?>
                                
                                            
                                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="page-item <?php echo e($news->currentPage() == $key+1 ? 'active' : ''); ?>">
                                                    <a class="page-link" href="<?php echo e($news->url($key+1)); ?>"><?php echo e($key+1); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                            
                                            <?php if($news->nextPageUrl()): ?>
                                                <li class="page-item">
                                                    <a class="page-link" href="<?php echo e($news->nextPageUrl()); ?>"><i class="fas fa-angle-double-right"></i></a>
                                                </li>
                                            <?php else: ?>
                                                <li class="page-item disabled">
                                                    <a class="page-link" href="#"><i class="fas fa-angle-double-right"></i></a>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </nav>
                                </div>
                                
                            </div>
                        </div>



                        <div class="col-30">
                            <aside class="blog__sidebar">

                                <div class="sidebar__widget">
                                    <h4 class="sidebar__widget-title">Latest Posts</h4>
                                    <div class="sidebar__post-list">

                                        <?php $__currentLoopData = $newss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <div class="sidebar__post-item">
                                            <div class="sidebar__post-thumb">
                                                <a href='blog-details/<?php echo e($news->id); ?>'><img src="<?php echo e(('uploads/' .$news->imgs)); ?>" alt=""></a>
                                            </div>
                                            <div class="sidebar__post-content">
                                                <h5 class="title"><a href="blog-details/<?php echo e($news->id); ?>"><?php echo e($news->title); ?></a></h5>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $evenss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <div class="sidebar__post-item">
                                            <div class="sidebar__post-thumb">
                                                <a href='blog-details2/<?php echo e($evens->id); ?>'><img src="<?php echo e(('uploads/' .$evens->imgs)); ?>" alt=""></a>
                                            </div>
                                            <div class="sidebar__post-content">
                                                <h5 class="title"><a href="blog-details2/<?php echo e($evens->id); ?>"><?php echo e($evens->title); ?></a></h5>
                                                <span class="date"><i class="flaticon-time"></i><?php echo e(\Carbon\Carbon::parse($evens->dob)->format('M d, Y')); ?></span>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                </div>

                            </aside>
                        </div>

                        
                    </div>
                </div>
            </div>
        </section>

    </main>
    <!-- main-area-end -->
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Royer\Royer\resources\views/blog.blade.php ENDPATH**/ ?>