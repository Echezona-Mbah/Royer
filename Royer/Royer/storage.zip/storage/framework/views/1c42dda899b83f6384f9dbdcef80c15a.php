<!doctype html>
<html class="no-js" lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
 <meta charset="utf-8">
 <meta http-equiv="x-ua-compatible" content="ie=edge">
 <title><?php echo e($title); ?></title>
 <meta name="description" content="Welcome to <?php echo e(env ('siteName')); ?>– your gateway to strategic investment opportunities and profit growth. Join our global community of entrepreneurs committed to financial excellence. Discover the power of collaborative investing and unlock your path to financial freedom with  <?php echo e(env ('siteName')); ?>.">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('new/img/favicon.png')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/bootstrap.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/animate.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/magnific-popup.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/fontawesome-all.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/flaticon.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/odometer.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/swiper-bundle.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/aos.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/default.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('new/assets/css/main.css')); ?>">

 <link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.css')); ?>">
<script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
</head>
<?php 
//$siteDomain = 'royal10investmentltd.com'
// $siteYear = date('Y')
// $siteName = 'Royal 10 Investment Limited'
// $sitePhone = '+123 9898 500'
// $siteAddress = '256 Avenue, Mark Street, NewYork City'
// $siteEmail = 'info@royal10investmentltd.com'
// $siteFacebook = 'https://www.facebook.com/'
// $siteTwitter = 'https://twitter.com/home'
// $siteInstagram = 'https://www.instagram.com/'
// $siteLinkedin = 'https://www.linkedin.com/'?><?php /**PATH C:\xampp\htdocs\Royer\Royer\resources\views/head.blade.php ENDPATH**/ ?>