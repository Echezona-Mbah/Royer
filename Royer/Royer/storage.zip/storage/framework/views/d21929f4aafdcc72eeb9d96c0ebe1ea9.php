<?php echo $__env->make('admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <div class="container-scroller">

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">

        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-12 mb-4 mb-xl-0">
              <h4 class="font-weight-bold text-dark">Hi, welcome back!</h4>
              <p class="font-weight-normal mb-2 text-muted">APRIL 1, 2019</p>
            </div>
          </div>
          <div class="row mt-3">
            <div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
              <div class="row flex-grow">
                <div class="col-sm-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                          <h4 style="color: black">Total Men Register</h4>
                          <h4 class="text-dark font-weight-bold mb-2"><?php echo e($totalUsers); ?></h4>
                          <canvas id="customers"></canvas>
                      </div>
                    </div>
                </div>
                <div class="col-sm-12 stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 style="color: black">Total News Upload</h4>
                          <h4 class="text-dark font-weight-bold mb-2"><?php echo e($new); ?></h4>
                          <canvas id="orders"></canvas>
                      </div>
                    </div>
               </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
              <div class="card mb-4">
                  <div class="card-body">
                      <div class="card">
                          <div class="card-body">
                              <h5 style="color: black"><i class="icon-location"></i> Total Evens Upload</h5>
                              <h4 class="text-dark font-weight-bold mb-2"><?php echo e($even); ?></h4>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="card mb-4">
                  <div class="card-body">
                      <div class="card">
                          <div class="card-body">
                              <h5 style="color: black"><i class="icon-share"></i> Total Testimonial Upload</h5>
                              <h4 class="text-dark font-weight-bold mb-2"><?php echo e($testimoial); ?></h4>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card">
                        <div class="card-body">
                            <h5 style="color: black"><i class="icon-upload"></i> Total Gallery Upload</h5>
                            <h4 class="text-dark font-weight-bold mb-2"><?php echo e($gallery); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body">
                    <div class="card">
                        <div class="card-body">
                            <h5 style="color: black"><i class="icon-pie-graph"></i> Total Project Upload</h5>
                            <h4 class="text-dark font-weight-bold mb-2"><?php echo e($project); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
          
          
          
          
          </div>


          <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h2 >ROYER 10 INVESTMENT</h2>
                <h4 class="card-description">
                 All Member
                </h4>

                <?php if($users->isEmpty()): ?>
                <p>No teams available.</p>
            <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>User</th>
                        <th> Name</th>
                        <th> Username</th>
                        <th> Email</th>
                        <th> Address</th>
                        <th> Phone Number</th>
                        
                        <th> Delete</th>

                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <?php if(Auth::user()->image): ?>
                        <td class="py-1">
                          <img src="<?php echo e(asset('uploads/' . $user->image)); ?>" alt="Team Image">
                      </td>
                        <?php else: ?>
                        <td class="py-1">
                        <img src="<?php echo e(asset('images/download.png')); ?>" alt="default-avatar" />
                      </td>
                        <?php endif; ?>

                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->address); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        
                        
                        <td>
                            <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>
                <?php endif; ?>
              </div>
            </div>
        </div>



        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Royer\Royer\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>