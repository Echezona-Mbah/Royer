<?php echo $__env->make('admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 120px;
            height: 40px;
            background-color: #007bff;
            color: #fff;
            border-radius: 5px;
            text-align: center;
            line-height: 40px;
            cursor: pointer;
        }
        .file-input-wrapper input[type=file] {
            font-size: 100px;
            position: absolute;
            top: 0;
            right: 0;
            opacity: 0;
            cursor: pointer;
        }
        .file-input-wrapper:hover {
            background-color: #0056b3;
        }
        .upload-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .upload-button:hover {
            background-color: #0056b3;
        }
</style>
<body>
  <div class="container-scroller">

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">

        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <div class="main-panel">

        
        <div class="content-wrapper">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 style="color:#c80d9f">Table Family </h4>
                    <p class="card-description">
                      
                    </p>

                    <?php if($allfamily->isEmpty()): ?>
                    <p>No about available.</p>
                <?php else: ?>
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th> Middle Name</th>
                            <th> Surname</th>
                            <th> Kindred</th>
                            <th> Village</th>
                            <th> Town</th>
                            <th> Local <br>Government Area</th>
                            <th> State of Origin</th>
                            <th> Business Location Address</th>
                            <th> Country of Residence</th>
                            <th> through Morocco</th>
                            <th> Year passed</th>
                            <th> City during</th>
                            <th> Telephone Number</th>
                            <th> WhatsApp <br> Number</th>
                            <th> Email</th>
                            <th> Marital </th>
                            <th> Mother Still</th>
                            <th>Nama Next Of Kins</th>
                            
                            <th> Village of Next Of Kins</th>
                            <th> Country of redidence of Next Of Kins</th>
                            <th> Relationship with Next Of Kins</th>
                            <th> Telephone of Next Of Kins</th>
                            <th> Whatapps Number of Next Of Kins</th>
                            <th> Password</th>
                            <th> Delete</th>


                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $allfamily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($family->name); ?></td>
                            <td><?php echo e($family->middle_name); ?></td>
                            <td><?php echo e($family->surname); ?></td>
                            <td><?php echo e($family->kindred); ?></td>
                            <td><?php echo e($family->village); ?></td>
                            <td><?php echo e($family->town); ?></td>
                            <td><?php echo e($family->Area); ?></td>
                            <td><?php echo e($family->origin); ?></td>
                            <td><?php echo e($family->address); ?></td>
                            <td><?php echo e($family->country); ?></td>
                            <td><?php echo e($family->pass_morocco); ?></td>
                            <td><?php echo e($family->year_morocco); ?></td>
                            <td><?php echo e($family->city_morocco); ?></td>
                            <td><?php echo e($family->telephone); ?></td>
                            <td><?php echo e($family->whatsapp); ?></td>
                            <td><?php echo e($family->email); ?></td>
                            <td><?php echo e($family->marital_status); ?></td>
                            <td><?php echo e($family->mother_alive); ?></td>
                            <td><?php echo e($family->name_kins); ?></td>
                            <td><?php echo e($family->village_kins); ?></td>
                            <td><?php echo e($family->redidence_kins); ?></td>
                            <td><?php echo e($family->relationship_kins); ?></td>
                            <td><?php echo e($family->telephone_kins); ?></td>
                            <td><?php echo e($family->whatsapp_kins); ?></td>
                            <td class="py-1">
                                <img src="<?php echo e(asset('uploads/' . $family->image)); ?>" alt="Team Image">
                            </td>
                            
                            <td>
                                <form action="<?php echo e(route('family.destroy', $family->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                      </table>
                    </div>
                    <?php endif; ?>
                  </div>
                </div>
            </div>
          </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->


  <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Royer\Royer\resources\views/admin/Family-table.blade.php ENDPATH**/ ?>