<!-- partial:partials/_sidebar.html -->
<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <div class="user-profile">
      <div class="user-image">
          <?php if(Auth::user()->image): ?>
          <img src="<?php echo e(asset('uploads/' . Auth::user()->image)); ?>" alt="profile" />
          <?php else: ?>
          <img src="<?php echo e(asset('images/download.png')); ?>" alt="default-avatar" />
          <?php endif; ?>
      </div>
      <div class="user-name">
          <?php echo e(Auth::user()->name); ?>

      </div>
      <div class="user-designation">
          <?php echo e(Auth::user()->username); ?>

      </div>
  </div>
  <ul class="nav">
      <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
              <i class="icon-box menu-icon"></i>
              <span class="menu-title">Dashboard</span>
          </a>
      </li>
      <li class="nav-item">
          <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="icon-disc menu-icon"></i>
              <span class="menu-title">Setting</span>
              <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('update-profile')); ?>">Profile</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('update-password')); ?>">Update Password</a>
                  </li>
              </ul>
          </div>
      </li>

    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#about" aria-expanded="false" aria-controls="ui-basic">
            <i class="icon-content-right menu-icon"></i>
            <span class="menu-title">About</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="about">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('about')); ?>">Upload About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('about-table')); ?>">About Table</a>
                </li>
            </ul>
        </div>
    </li>


    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#new" aria-expanded="false" aria-controls="ui-basic">
            <i class="icon-download menu-icon"></i>
            <span class="menu-title">News</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="new">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('new-us')); ?>">Upload New</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('new-table')); ?>">New Table</a>
                </li>
            </ul>
        </div>
    </li>


    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#even" aria-expanded="false" aria-controls="ui-basic">
            <i class="icon-disc menu-icon"></i>
            <span class="menu-title">Even</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="even">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('even-us')); ?>">Upload Even</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('even-table')); ?>">Even Table</a>
                </li>
            </ul>
        </div>
    </li>


    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#testimonial" aria-expanded="false" aria-controls="ui-basic">
            <i class="icon-disc menu-icon"></i>
            <span class="menu-title">Testimoial</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="testimonial">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('testimonial-us')); ?>">Upload Testimoial</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('testimonial-table')); ?>">Testimoial Table</a>
                </li>
            </ul>
        </div>
    </li>



      <li class="nav-item">
          <a class="nav-link" data-toggle="collapse" href="#team" aria-expanded="false" aria-controls="team">
              <i class="icon-head menu-icon"></i>
              <span class="menu-title">Team</span>
              <i class="menu-arrow"></i>
          </a>
          <div class="collapse" id="team">
              <ul class="nav flex-column sub-menu">
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('post-team')); ?>">Upload Team</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('team-table')); ?>">Team Table</a>
                  </li>
              </ul>
          </div>
      </li>


      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#service" aria-expanded="false" aria-controls="team">
            <i class="icon-folder menu-icon"></i>
            <span class="menu-title">Service</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="service">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('service-us')); ?>">Upload Service</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('service-table')); ?>">Service Table</a>
                </li>
            </ul>
        </div>
    </li>


    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#gallery" aria-expanded="false" aria-controls="team">
            <i class="icon-cog menu-icon"></i>
            <span class="menu-title">Gallery</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="gallery">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('gallery-us')); ?>">Upload Gallery</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('gallery-table')); ?>">Gallery Table</a>
                </li>
            </ul>
        </div>
    </li>



    <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#project" aria-expanded="false" aria-controls="team">
            <i class="icon-target menu-icon"></i>
            <span class="menu-title">Project</span>
            <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="project">
            <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('project-us')); ?>">Upload Project</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('project-table')); ?>">Project Table</a>
                </li>
            </ul>
        </div>
    </li>



    

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('contact-table')); ?>">
            <i class="icon-book menu-icon"></i>
            <span class="menu-title">Contact Table</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="icon-server menu-icon"></i>
            <span class="menu-title">Logout</span>
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </li>




      

  </ul>
</nav>
<!-- partial -->
<?php /**PATH C:\xampp\htdocs\Royer\Royer\resources\views\admin\sidebar.blade.php ENDPATH**/ ?>