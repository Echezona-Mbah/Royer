<?php $title = 'Blog Detail | Committed to investment orientation, profit growth, and extensive global business penetration.';?>
<?php
$siteName = 'Royal 10 Investment Limited'?>
<?php $sitePhone = '+123 9898 500'?>
<?php $siteAddress = '256 Avenue, Mark Street, NewYork City'?>
<?php $siteEmail = 'info@royal10investmentltd.com'?>
<?php $siteFacebook = 'https://www.facebook.com/'?>
<?php $siteTwitter = 'https://twitter.com/home'?>
<?php $siteInstagram = 'https://www.instagram.com/'?>
<?php $siteLinkedin = 'https://www.linkedin.com/'?>
<?php $siteYear = date('Y')?>
<?php echo $__env->make('lib', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<body>
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <main class="fix">
    <!-- breadcrumb-area -->
    <section class="breadcrumb__area breadcrumb__bg" data-background="<?php echo e(asset('img/image-cover.png')); ?>">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="breadcrumb__content">
              <h2 class="title">Blog Details</h2>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
                    <a href="./">Home</a>
                  </li>
                  <li class="breadcrumb-item active" aria-current="page">
                    Blog Details
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>
      <div class="breadcrumb__shape">
        <img src="<?php echo e(asset('assets/img/images/breadcrumb_shape01.png')); ?>" alt="" />
        <img src="<?php echo e(asset('assets/img/images/breadcrumb_shape02.png')); ?>" alt="" class="rightToLeft" />
        <img src="<?php echo e(asset('assets/img/images/breadcrumb_shape03.png')); ?>" alt="" />
        <img src="<?php echo e(asset('assets/img/images/breadcrumb_shape04.png')); ?>" alt="" />
        <img src="<?php echo e(asset('assets/img/images/breadcrumb_shape05.png')); ?>" alt="" class="alltuchtopdown" />
      </div>
    </section>
    <!-- breadcrumb-area-end -->
    <!-- blog-details-area -->
    <section class="blog__details-area">
      <div class="container">
        <div class="blog__inner-wrap">
          <div class="row">
            

            <?php $__currentLoopData = $evens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $even): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-70">
              <div class="blog__details-wrap">
                <div class="blog__details-thumb">
                  <img src="<?php echo e(asset('uploads/' .$even->imgs)); ?>" width="auto" alt="" />
                </div>
                <div class="blog__details-content">
                  <h2 class="title">
                    <?php echo e($even->title); ?>

                  </h2>
                  <div class="blog-post-meta">
                    <ul class="list-wrap">
                      <li>
                        <a class="blog__post-tag-two" href="blog">Even</a>
                      </li>
                      <li>
                        <div class="blog-avatar">
                          <?php if($getUserseven->image == NULL): ?>
                          <div class="avatar-thumb">
                              <img src="<?php echo e(asset('images/download.png')); ?>" alt="default-avatar" />
                           </div>
                          <?php else: ?>

                          <div class="avatar-thumb">
                              <img src="<?php echo e(('uploads/' .$getUserseven->image)); ?>" alt="">
                          </div>
                              
                          <?php endif; ?>
                          <div class="avatar-content">
                            <p>
                              By <?php echo e($getUserseven->name); ?>

                            </p>
                          </div>
                        </div>
                      </li><?php echo e(\Carbon\Carbon::parse($even->dob)->format('M d, Y')); ?></li>

                    </ul>
                  </div>
                  <p>
                    <?php echo e($even->discription); ?>

                  </p>
                  <blockquote>

                  </blockquote>

                </div>


              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            <div class="col-30">
              <aside class="blog__sidebar">

                <div class="sidebar__widget">
                  <h4 class="sidebar__widget-title">Latest Posts</h4>
                  <div class="sidebar__post-list">

                    <?php $__currentLoopData = $newss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="sidebar__post-item">
                        <div class="sidebar__post-thumb">
                            <a href="<?php echo e(route('blog-details', ['id' => $news->id])); ?>"><img src="<?php echo e(asset('uploads/' .$news->imgs)); ?>" alt=""></a>
                        </div>
                        <div class="sidebar__post-content">
                            <h5 class="title"><a href="<?php echo e(route('blog-details', ['id' => $news->id])); ?>"><?php echo e($news->title); ?></a></h5>
                            <span class="date"><i class="flaticon-time"></i><?php echo e(\Carbon\Carbon::parse($news->dob)->format('M d, Y')); ?></span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $evenss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="sidebar__post-item">
                        <div class="sidebar__post-thumb">
                            <a href="<?php echo e(route('blog-details2', ['id' => $evens->id])); ?>"><img src="<?php echo e(asset('uploads/' .$evens->imgs)); ?>" alt=""></a>
                        </div>
                        <div class="sidebar__post-content">
                            <h5 class="title"><a href="<?php echo e(route('blog-details2', ['id' => $evens->id])); ?>"><?php echo e($evens->title); ?></a></h5>
                            <span class="date"><i class="flaticon-time"></i><?php echo e(\Carbon\Carbon::parse($evens->dob)->format('M d, Y')); ?></span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                </div>

              </aside>
            </div>
          </div>
        </div>
      </div>
    </section>

  </main>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\Royer\Royer\resources\views\blog-details2.blade.php ENDPATH**/ ?>