<?php
$siteDomain = 'royal10investmentltd.com';
$siteYear = date('Y');
$siteName = 'Royal 10 Investment Limited';
$sitePhone = '+123 9898 500';
$siteAddress = '256 Avenue, Mark Street, NewYork City';
$siteEmail = 'info@royal10investmentltd.com';
$siteFacebook = 'https://www.facebook.com/';
$siteTwitter = 'https://twitter.com/home';
$siteInstagram = 'https://www.instagram.com/';
$siteLinkedin = 'https://www.linkedin.com/';
